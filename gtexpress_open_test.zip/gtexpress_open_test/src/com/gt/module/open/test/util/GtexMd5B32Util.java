package com.gt.module.open.test.util;

import java.security.MessageDigest;


import sun.misc.BASE64Encoder;

public class GtexMd5B32Util {
	/**
	 * md5加密
	 * 
	 * @param str
	 * @return
	 */
	public static String getMd5(String str) {
		StringBuffer sb = new StringBuffer(32);
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] array = md.digest(str.getBytes("UTF-8"));
			for (int i = 0; i < array.length; i++) {
				sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100)
						.toLowerCase().substring(1, 3));
			}
			BASE64Encoder b64 = new BASE64Encoder();
			String result = b64.encode(array);
			System.out.println("base64:  " + result);
		} catch (Exception e) {
			System.out.println("Can not encode the string '" + str
					+ "' to MD5!");
			e.printStackTrace();
			return null;
		}
		return sb.toString().toUpperCase();
	}

	/**
	 * 判断md5加密是否正确
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isMd5B32Result(String sign, String str) {
		if (sign.equals(str)) {
			return true;
		}
		return false;
	}

	
}
