package com.gt.module.open.test.platform;

import java.io.IOException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;

import com.gt.module.open.test.util.GtexMd5B32Util;


/**
 * 单号查询示例
 * @ClassName: TestOrderQryByCarrier 
 * @date 2015年9月6日 上午9:13:24 
 */
public class TestOrderQryByCarrier {
	
	public static String insertPostHttp(String gtex_type,String gtex_sign,String gtex_key, String gtex_user_login,String gtex_method,String timestamp,String gtex_params){
		String responseMsg = "";
		//1.构造HttpClient的实例
        HttpClient httpClient=new HttpClient();
        
        httpClient.getParams().setContentCharset("utf-8");
        
        String url="http://open.gtexpress.cn/query/order/query.action";
        
        //2.构造PostMethod的实例
        PostMethod postMethod=new PostMethod(url);
        
        //3.把参数值放入到PostMethod对象中
        postMethod.addParameter("gtex_type", gtex_type);
        postMethod.addParameter("gtex_sign", gtex_sign);
        postMethod.addParameter("gtex_key", gtex_key);
        postMethod.addParameter("gtex_user_login", gtex_user_login);
        postMethod.addParameter("gtex_method", gtex_method);
        postMethod.addParameter("timestamp", timestamp);
        postMethod.addParameter("gtex_params", gtex_params);
        
        try {
            // 4.执行postMethod,调用http接口
            httpClient.executeMethod(postMethod);//200
            //5.读取内容
            responseMsg = postMethod.getResponseBodyAsString().trim();
            //System.out.println(responseMsg);
            

        } catch (HttpException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //7.释放连接
            postMethod.releaseConnection();
        }
        return responseMsg;
	}
	
	public static void main(String[] args) {
		 System.out.println(System.currentTimeMillis());
		 //数据传输格式
		 String gtex_type="json";
		 //用户账号
		 String gtex_user_login="yabo666";
		 //appKey
		 String gtex_key="gtexpress";
		 //接口方法名
		 String gtex_method="getOrderByCarrier";
		 //当前时间
		 String timestamp="2015-02-01 15:00:30";
		 //数字签名
		 String gtex_sign = gtex_key + gtex_user_login + timestamp;
		 gtex_sign = GtexMd5B32Util.getMd5(gtex_sign);
		 //请求参数
		 String gtex_params="{\"gtex_carrier_code\":\"huitong\",\"gtex_bill_code\":\"350301727598\"}";	
		 String result=insertPostHttp(gtex_type, gtex_sign, gtex_key, gtex_user_login,gtex_method, timestamp, gtex_params);
		 System.out.println("post方式调用http接口\n"+result);
		 System.out.println(System.currentTimeMillis());
	}

}
